Trailer Website

This is a simple website that displays some information about a few movies and plays trailers.
